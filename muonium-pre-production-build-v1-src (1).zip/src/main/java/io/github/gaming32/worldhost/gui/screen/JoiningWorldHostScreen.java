package io.github.gaming32.worldhost.gui.screen;

import io.github.gaming32.worldhost.WorldHost;
import net.minecraft.client.gui.screens.DisconnectedScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.NotNull;

//#if MC >= 1.20.0
import net.minecraft.client.gui.GuiGraphics;
//#else
//$$ import com.mojang.blaze3d.vertex.PoseStack;
//#endif

public class JoiningWorldHostScreen extends WorldHostScreen {
    private static final Component MESSAGE = Component.translatable("world-host.joining_world_host");

    // Fix (#8): the host's client silently ignores join requests when its world
    // isn't published (and a dead network path can swallow responses too), which
    // left the joiner stuck on this screen forever with no error. This timeout
    // doesn't change the happy path — it just guarantees the screen eventually
    // resolves to a visible error instead of hanging until manual cancel.
    private static final int TIMEOUT_TICKS = 600; // 30 seconds at 20 tps

    private int elapsedTicks;

    public final Screen parent;

    public JoiningWorldHostScreen(Screen parent) {
        super(MESSAGE);
        this.parent = parent;
    }

    @Override
    protected void init() {
        addRenderableWidget(
            button(CommonComponents.GUI_CANCEL, b -> onClose())
                .pos(width / 2 - 100, height / 4 + 132)
                .width(200)
                .build()
        );
    }

    @Override
    public void tick() {
        if (++elapsedTicks > TIMEOUT_TICKS) {
            assert minecraft != null;
            if (WorldHost.protoClient != null) {
                WorldHost.protoClient.setAttemptingToJoin(null);
            }
            minecraft.setScreen(new DisconnectedScreen(
                parent,
                Component.translatable("world-host.join_timed_out"),
                Component.translatable("world-host.join_timed_out.desc")
            ));
        }
    }

    @Override
    public void render(
        @NotNull
        //#if MC < 1.20.0
        //$$ PoseStack context,
        //#else
        GuiGraphics context,
        //#endif
        int mouseX, int mouseY, float delta
    ) {
        whRenderBackground(context, mouseX, mouseY, delta);
        drawCenteredString(context, font, MESSAGE, width / 2, height / 2 - 50, 0xffffff);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void onClose() {
        assert minecraft != null;
        minecraft.setScreen(parent);
        if (WorldHost.protoClient != null) {
            WorldHost.protoClient.setAttemptingToJoin(null);
        }
    }
}
