package io.github.gaming32.worldhost.origincheck.checker;

import io.github.gaming32.worldhost.origincheck.parser.SimpleIniParser;
import org.jetbrains.annotations.Nullable;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class WindowsOriginChecker extends AbstractOriginChecker {
    @Override
    String getCheckedMarker() {
        return "WorldHostOriginChecked";
    }

    @Override
    String getOriginAttributeName() {
        return "Zone.Identifier";
    }

    @Override
    List<@Nullable String> parseOrigins(ByteBuffer bb) throws IOException {
        final var zoneIdentifier = parseZoneIdentifier(bb);
        final var zoneTransfer = zoneIdentifier.get("ZoneTransfer");
        if (zoneTransfer == null) {
            return List.of();
        }
        // Fix (#20): ReferrerUrl is the page the download link was clicked on (a search engine,
        // Discord, a wiki, etc.), not where the file was downloaded from. Treating it as a
        // download origin caused false "nonstandard download origin" warnings for legitimate
        // downloads. HostUrl is the actual download URL; toUriList skips it if absent.
        return Arrays.asList(zoneTransfer.get("HostUrl"));
    }

    private static Map<String, Map<String, String>> parseZoneIdentifier(ByteBuffer bb) throws IOException {
        // Fix (#20): some browsers write Zone.Identifier as UTF-16 with a BOM, which failed to
        // decode under the native encoding, so those files never parsed and silently bypassed
        // the origin check. Detect the BOM and decode accordingly.
        Charset charset = null;
        if (bb.remaining() >= 2) {
            final int first = bb.get(bb.position()) & 0xff;
            final int second = bb.get(bb.position() + 1) & 0xff;
            if ((first == 0xff && second == 0xfe) || (first == 0xfe && second == 0xff)) {
                charset = StandardCharsets.UTF_16; // decodes either endianness and strips the BOM
            }
        }
        if (charset == null) {
            final var nativeEncoding = System.getProperty("native.encoding"); // Fix (#20): null-safe
            charset = nativeEncoding != null ? Charset.forName(nativeEncoding) : Charset.defaultCharset();
        }
        try (var reader = new BufferedReader(
            new InputStreamReader(
                new ByteArrayInputStream(bb.array(), bb.arrayOffset() + bb.position(), bb.remaining()),
                charset
            )
        )) {
            return SimpleIniParser.parse(reader);
        }
    }
}
