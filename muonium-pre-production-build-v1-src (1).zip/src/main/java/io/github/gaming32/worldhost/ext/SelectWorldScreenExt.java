package io.github.gaming32.worldhost.ext;

public interface SelectWorldScreenExt {
    boolean wh$shareButtonPressed();

    // Fix (#5): the share flag was never reset, so a cancelled share still
    // published the world on the next normal "Play World" click.
    void wh$resetShareButtonPressed();
}
